# Event Architect AI

GitHub → Streamlit Community Cloud에서 바로 실행할 수 있는 행사장 AI 설계 프로토타입입니다.

## 포함 기능
- 홈 화면: 대시보드 / AI 보고서
- 오른쪽 위 설정: 로그인 정보 / 로그아웃 / 앱 설정
- 회원가입 / 로그인
- 행사명, 행사 목적, 예상 방문객 수, 예산, 장소, 진행시간 입력
- AI 이벤트 디자인 생성
- 디지털 트윈 행사장 배치도
- 무대 / 푸드 존 / 비상구 / 정보 센터 / 부스 / 화장실 / 의료 센터 / 휴식 구역
- 시설별 배치 이유 확인
- AI 군중 시뮬레이션 및 Heatmap
- AI 디자인 상담 채팅
- 안전성 / 접근성 / 동선 효율성 / 혼잡도 / 예산 효율성 점수
- Before / After 비교
- AI 행사 설계 Workflow
- 상사 보고용 Markdown 보고서 다운로드

## 실행
```bash
pip install -r requirements.txt
streamlit run app.py
```

## Streamlit Cloud
1. GitHub 저장소에 app.py와 requirements.txt 업로드
2. Streamlit Community Cloud에서 New app
3. Main file path를 app.py로 지정
4. Deploy

## 참고
현재 회원가입 데이터는 Streamlit 세션에 저장되는 데모용 인증입니다.
앱이 재시작되거나 재배포되면 계정 데이터가 유지되지 않을 수 있습니다.
실제 서비스로 확장하려면 Firebase / Supabase / 별도 DB와 인증 시스템을 연결하세요.

또한 현재 AI 채팅은 API 키 없이도 동작하는 프로토타입 규칙 기반 응답입니다.
